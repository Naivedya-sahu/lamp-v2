#!/bin/bash
#
# Draw all components from library in a grid layout
# Useful for testing and visual verification of the component library
#
# Usage: ./test_library.sh [RM2_IP]

set -e

RM2_IP="${1:-10.11.99.1}"
LAMP="/opt/bin/lamp"
LIBRARY="component_library.json"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo "=========================================="
echo "Component Library Test - Grid Layout"
echo "=========================================="
echo -e "${BLUE}Target:${NC} $RM2_IP"
echo ""

# Check if library exists
if [ ! -f "$LIBRARY" ]; then
    echo -e "${RED}Error: Component library '$LIBRARY' not found${NC}"
    exit 1
fi

# Test connection
echo -e "${BLUE}Testing SSH connection...${NC}"
if ! ssh root@$RM2_IP "test -x $LAMP" 2>/dev/null; then
    echo -e "${RED}Error: Cannot connect to $RM2_IP${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Connected${NC}"
echo ""

# Generate grid layout and send all components
echo -e "${BLUE}Drawing all components in grid layout...${NC}"
python3 << EOF | ssh root@$RM2_IP "$LAMP"
import json
import sys

# reMarkable 2 screen dimensions
SCREEN_WIDTH = 1404
SCREEN_HEIGHT = 1872

# Grid layout parameters
COLS = 4
MARGIN = 50
SPACING_X = (SCREEN_WIDTH - 2 * MARGIN) // COLS
SPACING_Y = 250
START_X = MARGIN + SPACING_X // 2
START_Y = MARGIN + 100

# Read library
with open("$LIBRARY", "r") as f:
    library = json.load(f)

# Sort components for consistent layout
components = sorted(library.items())
total = len(components)

print(f"# Drawing {total} components in {COLS} columns", file=sys.stderr)

# Draw grid of components
row = 0
col = 0

for name, comp in components:
    # Calculate position in grid
    x = START_X + col * SPACING_X
    y = START_Y + row * SPACING_Y
    
    # Scale to fit in grid cell (smaller for dense packing)
    scale = 0.8
    
    # Get anchor offset
    anchor_x = comp["anchor"][0]
    anchor_y = comp["anchor"][1]
    
    # Draw component label (using pen_line to write text is complex, skip for now)
    # Instead, just draw the component
    
    # Transform and output commands
    for cmd in comp["commands"]:
        cmd_type = cmd["type"]
        
        if cmd_type == "pen_down":
            px = int((cmd["x"] - anchor_x) * scale + x)
            py = int((cmd["y"] - anchor_y) * scale + y)
            print(f"pen down {px} {py}")
        
        elif cmd_type == "pen_move":
            px = int((cmd["x"] - anchor_x) * scale + x)
            py = int((cmd["y"] - anchor_y) * scale + y)
            print(f"pen move {px} {py}")
        
        elif cmd_type == "pen_up":
            print("pen up")
        
        elif cmd_type == "pen_line":
            x1 = int((cmd["x1"] - anchor_x) * scale + x)
            y1 = int((cmd["y1"] - anchor_y) * scale + y)
            x2 = int((cmd["x2"] - anchor_x) * scale + x)
            y2 = int((cmd["y2"] - anchor_y) * scale + y)
            print(f"pen line {x1} {y1} {x2} {y2}")
        
        elif cmd_type == "pen_rectangle":
            x1 = int((cmd["x1"] - anchor_x) * scale + x)
            y1 = int((cmd["y1"] - anchor_y) * scale + y)
            x2 = int((cmd["x2"] - anchor_x) * scale + x)
            y2 = int((cmd["y2"] - anchor_y) * scale + y)
            print(f"pen rectangle {x1} {y1} {x2} {y2}")
        
        elif cmd_type == "pen_circle":
            cx = int((cmd["cx"] - anchor_x) * scale + x)
            cy = int((cmd["cy"] - anchor_y) * scale + y)
            r = int(cmd["r"] * scale)
            print(f"pen circle {cx} {cy} {r}")
    
    # Draw small label circle at anchor point for reference
    print(f"pen circle {x} {y} 3")
    
    print(f"# {name} at ({x}, {y})", file=sys.stderr)
    
    # Move to next position
    col += 1
    if col >= COLS:
        col = 0
        row += 1

print(f"# Grid complete: {row + 1} rows, {COLS} columns", file=sys.stderr)
EOF

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✓ Grid layout complete!${NC}"
    echo ""
    echo "All components drawn in ${COLS}x${ROWS} grid"
    echo "Check your reMarkable 2 screen"
else
    echo ""
    echo -e "${RED}✗ Error drawing grid${NC}"
    exit 1
fi
