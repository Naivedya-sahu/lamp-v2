#!/bin/bash
#
# Send component from JSON library to reMarkable 2
# Extracts pen commands from component_library.json and sends to lamp
#
# Usage: ./send_component.sh <component_name> [scale] [x] [y] [RM2_IP]
#
# Examples:
#   ./send_component.sh R                    # Auto-scale and center
#   ./send_component.sh NPN_BJT 2 500 800   # Scale 2x at (500,800)
#   ./send_component.sh OPAMP 1.5            # Scale 1.5x, auto-center

set -e

# Check arguments
if [ $# -lt 1 ]; then
    cat << 'EOF'
Usage: ./send_component.sh <component_name> [scale] [x] [y] [RM2_IP]

Arguments:
  component_name - Component name from library (required)
  scale          - Scale factor (default: 1.0)
  x              - X offset in pixels (default: from library anchor)
  y              - Y offset in pixels (default: from library anchor)
  RM2_IP         - reMarkable 2 IP address (default: 10.11.99.1)

Examples:
  ./send_component.sh R                    # Draw resistor at library position
  ./send_component.sh NPN_BJT 2            # Scale BJT 2x
  ./send_component.sh OPAMP 1.5 500 800   # Scale 1.5x at (500,800)
  ./send_component.sh VDC 1 0 0 10.11.99.1

Available components in library:
  R, C, L, D, VDC, VAC, GND, NPN_BJT, PNP_BJT, 
  N_MOSFET, P_MOSFET, OPAMP, P_CAP, ZD, SW_CL, SW_OP

Note: Requires component_library.json in current directory
EOF
    exit 1
fi

# Parse arguments
COMPONENT="$1"
SCALE="${2:-1.0}"
OFFSET_X="${3:-}"
OFFSET_Y="${4:-}"
RM2_IP="${5:-10.11.99.1}"
LAMP="/opt/bin/lamp"
LIBRARY="component_library.json"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo "=========================================="
echo "Component to reMarkable 2"
echo "=========================================="

# Check if library exists
if [ ! -f "$LIBRARY" ]; then
    echo -e "${RED}Error: Component library '$LIBRARY' not found${NC}"
    echo "Please run: python3 component_library_builder.py ../components"
    exit 1
fi

echo -e "${BLUE}Component:${NC} $COMPONENT"
echo -e "${BLUE}Scale:${NC} $SCALE"
echo -e "${BLUE}Position:${NC} ${OFFSET_X:-auto}, ${OFFSET_Y:-auto}"
echo -e "${BLUE}Target:${NC} $RM2_IP"
echo ""

# Test connection
echo -e "${BLUE}Testing SSH connection...${NC}"
if ! ssh root@$RM2_IP "test -x $LAMP" 2>/dev/null; then
    echo -e "${RED}Error: Cannot connect to $RM2_IP or lamp not found${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Connected${NC}"
echo ""

# Extract component from JSON using Python
echo -e "${BLUE}Extracting component from library...${NC}"
PEN_COMMANDS=$(python3 << EOF
import json
import sys

# Read library
with open("$LIBRARY", "r") as f:
    library = json.load(f)

# Check if component exists
if "$COMPONENT" not in library:
    print(f"Error: Component '$COMPONENT' not found in library", file=sys.stderr)
    print(f"Available components: {', '.join(library.keys())}", file=sys.stderr)
    sys.exit(1)

comp = library["$COMPONENT"]

# Get anchor point
anchor_x = comp["anchor"][0]
anchor_y = comp["anchor"][1]

# Parse scale and offsets
scale = float("$SCALE")
offset_x = anchor_x if "$OFFSET_X" == "" else int("$OFFSET_X")
offset_y = anchor_y if "$OFFSET_Y" == "" else int("$OFFSET_Y")

# Transform commands
commands = []
for cmd in comp["commands"]:
    cmd_type = cmd["type"]
    
    if cmd_type == "pen_down":
        x = int((cmd["x"] - anchor_x) * scale + offset_x)
        y = int((cmd["y"] - anchor_y) * scale + offset_y)
        commands.append(f"pen down {x} {y}")
    
    elif cmd_type == "pen_move":
        x = int((cmd["x"] - anchor_x) * scale + offset_x)
        y = int((cmd["y"] - anchor_y) * scale + offset_y)
        commands.append(f"pen move {x} {y}")
    
    elif cmd_type == "pen_up":
        commands.append("pen up")
    
    elif cmd_type == "pen_line":
        x1 = int((cmd["x1"] - anchor_x) * scale + offset_x)
        y1 = int((cmd["y1"] - anchor_y) * scale + offset_y)
        x2 = int((cmd["x2"] - anchor_x) * scale + offset_x)
        y2 = int((cmd["y2"] - anchor_y) * scale + offset_y)
        commands.append(f"pen line {x1} {y1} {x2} {y2}")
    
    elif cmd_type == "pen_rectangle":
        x1 = int((cmd["x1"] - anchor_x) * scale + offset_x)
        y1 = int((cmd["y1"] - anchor_y) * scale + offset_y)
        x2 = int((cmd["x2"] - anchor_x) * scale + offset_x)
        y2 = int((cmd["y2"] - anchor_y) * scale + offset_y)
        commands.append(f"pen rectangle {x1} {y1} {x2} {y2}")
    
    elif cmd_type == "pen_circle":
        cx = int((cmd["cx"] - anchor_x) * scale + offset_x)
        cy = int((cmd["cy"] - anchor_y) * scale + offset_y)
        r = int(cmd["r"] * scale)
        commands.append(f"pen circle {cx} {cy} {r}")

# Output commands
for cmd in commands:
    print(cmd)

# Print info to stderr
print(f"Extracted {len(commands)} commands", file=sys.stderr)
print(f"Position: ({offset_x}, {offset_y}), Scale: {scale}x", file=sys.stderr)
EOF
)

# Check if extraction was successful
if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to extract component${NC}"
    echo "$PEN_COMMANDS"
    exit 1
fi

# Get command count
CMD_COUNT=$(echo "$PEN_COMMANDS" | wc -l)
echo -e "${GREEN}✓ Extracted $CMD_COUNT commands${NC}"
echo ""

# Show preview
echo -e "${YELLOW}Preview (first 5 commands):${NC}"
echo "$PEN_COMMANDS" | head -5
echo "..."
echo ""

# Send to reMarkable 2
echo -e "${BLUE}Sending to reMarkable 2...${NC}"
echo "$PEN_COMMANDS" | ssh root@$RM2_IP "$LAMP"

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✓ Drawing complete!${NC}"
    echo ""
    echo "Component: $COMPONENT"
    echo "Commands sent: $CMD_COUNT"
    echo "Check your reMarkable 2 screen"
else
    echo ""
    echo -e "${RED}✗ Error sending commands${NC}"
    exit 1
fi
